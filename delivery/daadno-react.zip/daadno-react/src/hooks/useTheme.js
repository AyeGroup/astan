import { useCallback, useEffect, useState } from "react";

// The design's dark palette hangs off `data-theme="dark"` on <html> (daadno.css).
// The choice is remembered per browser; storage can be unavailable (private mode),
// so every access is guarded and the page still works without it.
const KEY = "daadno-theme";

function readStored() {
  try {
    const v = localStorage.getItem(KEY);
    return v === "dark" || v === "light" ? v : null;
  } catch {
    return null;
  }
}

export function useTheme() {
  const [theme, setTheme] = useState(() => readStored() ?? "light");

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    try {
      localStorage.setItem(KEY, theme);
    } catch {
      /* not persisted; fine */
    }
  }, [theme]);

  const toggle = useCallback(() => setTheme((t) => (t === "dark" ? "light" : "dark")), []);
  return { theme, toggle };
}
