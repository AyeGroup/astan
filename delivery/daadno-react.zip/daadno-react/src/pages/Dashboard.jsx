import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import DesktopDashboard from "../components/dashboard/DesktopDashboard";
import MobileDashboard from "../components/dashboard/MobileDashboard";
import { useMediaQuery } from "../hooks/useMediaQuery";
import { useTheme } from "../hooks/useTheme";

// One page, two layouts: the sidebar layout from 900px up, the phone layout below.
// The composer's text lives here so it survives switching between them, and a
// question asked on the landing page arrives as ?q=… already written in.
export default function Dashboard() {
  const isDesktop = useMediaQuery("(min-width: 900px)");
  const { theme, toggle } = useTheme();
  const [params, setParams] = useSearchParams();
  const [draft, setDraft] = useState(() => params.get("q") ?? "");
  const inputRef = useRef(null);

  useEffect(() => {
    document.title = "دادنو | داشبورد";
    if (params.has("q")) setParams({}, { replace: true });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const focus = useCallback(() => {
    const el = inputRef.current;
    if (!el) return;
    // The hero clips its overflow; a scrolling focus would shift its content inside it.
    el.focus({ preventScroll: true });
    el.setSelectionRange(el.value.length, el.value.length);
  }, []);

  const onPick = useCallback((prompt) => {
    setDraft(prompt);
    requestAnimationFrame(focus);
  }, [focus]);

  const onSend = useCallback((text) => {
    // TODO: send `text` to the chat API and open the conversation.
    console.info("[daadno] question:", text);
    setDraft("");
  }, []);

  const onOpenService = useCallback((id) => {
    // TODO: route to the service's flow, e.g. navigate(`/services/${id}`).
    console.info("[daadno] open service:", id);
  }, []);

  const composer = { value: draft, onChange: setDraft, onSend, onPick, focus, inputRef };
  const shared = { composer, theme, onToggleTheme: toggle, onOpenService };

  return isDesktop
    ? <DesktopDashboard {...shared} onNewFile={() => {}} onNewChat={() => { setDraft(""); focus(); }} />
    : <MobileDashboard {...shared} />;
}
