import { useEffect } from "react";
import Hero from "../components/landing/Hero";
import { Marquee, Stats } from "../components/landing/Stats";
import TryBox from "../components/landing/TryBox";
import Why from "../components/landing/Why";
import Services from "../components/landing/Services";
import Steps from "../components/landing/Steps";
import Audience from "../components/landing/Audience";
import Trust from "../components/landing/Trust";
import Testimonials from "../components/landing/Testimonials";
import Pricing from "../components/landing/Pricing";
import Faq from "../components/landing/Faq";
import { FinalCta, Footer, StickyCta } from "../components/landing/Footer";

export default function Landing() {
  useEffect(() => {
    document.title = "دادنو | دستیار حقوقی هوشمند";
  }, []);

  return (
    <div className="lp">
      <Hero />
      <Stats />
      <Marquee />
      <TryBox />
      <Why />
      <Services />
      <Steps />
      <Audience />
      <Trust />
      <Testimonials />
      <Pricing />
      <Faq />
      <FinalCta />
      <Footer />
      <StickyCta />
    </div>
  );
}
