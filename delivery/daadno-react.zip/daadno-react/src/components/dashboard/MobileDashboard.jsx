import { useState } from "react";
import Icon from "../Icon";
import Logo from "../Logo";
import { Composer, HeaderActions, QuickTools, RecentActivity, ServiceGrid } from "./Shared";
import { MOBILE_TABS, USER } from "../../data/dashboard";

export default function MobileDashboard({ composer, theme, onToggleTheme, onOpenService }) {
  const [tab, setTab] = useState("home");

  return (
    <div className="hy hy-m">
      <header className="hy-m-head">
        <div className="deco">
          <span style={{ width: 220, height: 220, left: -80, top: -90 }} />
          <span style={{ width: 150, height: 150, right: -60, bottom: -70, opacity: 0.4 }} />
        </div>
        <div className="hy-m-top on-dark">
          <div className="hy-brand"><Logo /></div>
          <span className="sp" />
          <HeaderActions btnClass="hy-gbtn" theme={theme} onToggleTheme={onToggleTheme} />
        </div>
        <label className="hy-gsearch">
          <Icon name="search" />
          <input type="search" placeholder="جستجو در گفتگوها، پرونده‌ها و اسناد…" aria-label="جستجو" />
        </label>
        <div className="greet">
          <h1>سلام، {USER.firstName}!</h1>
          <h2>چه کمکی از دستم برمیاد؟</h2>
          <p>مسئله حقوقی‌تان را بنویسید یا یک ابزار انتخاب کنید.</p>
        </div>
        <Composer {...composer} />
        <QuickTools onPick={composer.onPick} />
      </header>

      <div className="hy-m-body">
        <ServiceGrid className="hy-m-grid" onOpen={onOpenService} />
        <RecentActivity />
      </div>

      <nav className="hy-bnav" aria-label="ناوبری اصلی">
        {MOBILE_TABS.map((t) => (
          <a
            key={t.id}
            href={`#${t.id}`}
            className={tab === t.id ? "on" : undefined}
            aria-current={tab === t.id ? "page" : undefined}
            onClick={(e) => {
              e.preventDefault();
              setTab(t.id);
            }}
          >
            <span><Icon name={t.icon} /></span>{t.label}
          </a>
        ))}
      </nav>
    </div>
  );
}
