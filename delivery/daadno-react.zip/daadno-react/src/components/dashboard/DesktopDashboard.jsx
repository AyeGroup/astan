import { useState } from "react";
import Icon from "../Icon";
import Logo from "../Logo";
import Sidebar from "./Sidebar";
import { Composer, HeaderActions, QuickTools, RecentActivity, ServiceGrid } from "./Shared";
import { USER } from "../../data/dashboard";

export default function DesktopDashboard({ composer, theme, onToggleTheme, onOpenService, onNewFile, onNewChat }) {
  const [collapsed, setCollapsed] = useState(false);
  const [activeId, setActiveId] = useState("notices");

  return (
    <div className="hy hy-app">
      <Sidebar
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed((v) => !v)}
        activeId={activeId}
        onSelect={setActiveId}
        onNewFile={onNewFile}
        onNewChat={onNewChat}
      />

      <main className="hy-main">
        <header className="hy-top">
          <label className="hy-search">
            <Icon name="search" />
            <input type="search" placeholder="جستجو در گفتگوها، پرونده‌ها و اسناد…" aria-label="جستجو" />
          </label>
          <span className="sp" />
          <HeaderActions btnClass="hy-iconbtn" theme={theme} onToggleTheme={onToggleTheme} />
        </header>

        <section className="hy-hero">
          <div className="deco">
            <span style={{ width: 280, height: 280, left: -90, top: -120 }} />
            <span style={{ width: 160, height: 160, left: 120, bottom: -110, opacity: 0.35 }} />
            <span style={{ width: 200, height: 200, right: -70, bottom: -120, opacity: 0.4 }} />
          </div>
          <div className="hy-emb on-dark"><Logo /></div>
          <h1>سلام، {USER.firstName}!</h1>
          <h2>چه کمکی از دستم برمیاد؟</h2>
          <p>مسئله حقوقی‌تان را بنویسید یا یکی از ابزارهای زیر را انتخاب کنید.</p>
          <Composer {...composer} hint="پاسخ‌ها مبتنی بر قوانین جاری ایران" />
          <QuickTools onPick={composer.onPick} />
        </section>

        <ServiceGrid className="hy-grid" onOpen={onOpenService} />

        <div className="hy-bottom">
          <RecentActivity />
          <section className="hy-help">
            <span className="ic"><Icon name="scale" /></span>
            <b>قوانین پیچیده؟ ما اینجا هستیم.</b>
            <p>دستیار حقوقی شما؛ سریع، دقیق و همیشه در دسترس.</p>
            <button type="button" className="hy-btn" onClick={composer.focus}>
              <Icon name="chat" />شروع گفتگو
            </button>
          </section>
        </div>
      </main>
    </div>
  );
}
