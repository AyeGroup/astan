import Icon from "../Icon";
import Logo from "../Logo";
import { CASE_FILES, RECENT_CHATS, REQUESTS, USER } from "../../data/dashboard";

function Group({ icon, title, onAdd, addLabel, children }) {
  return (
    <section className="hy-sgroup">
      <div className="hy-sgroup-h">
        <Icon name={icon} />
        <span className="lbl">{title}</span>
        {onAdd && (
          <button type="button" className="add" aria-label={addLabel} onClick={onAdd}>
            <Icon name="plus" />
          </button>
        )}
      </div>
      <div className="hy-sitems">{children}</div>
    </section>
  );
}

function Item({ id, icon, active, onSelect, title, children, count }) {
  return (
    <button
      type="button"
      className={active ? "hy-sitem on" : "hy-sitem"}
      aria-current={active ? "page" : undefined}
      title={title}
      onClick={() => onSelect(id)}
    >
      <span className="ic"><Icon name={icon} /></span>
      <span className="t"><b>{title}</b>{children}</span>
      {count && <span className="cnt">{count}</span>}
    </button>
  );
}

export default function Sidebar({ collapsed, onToggleCollapse, activeId, onSelect, onNewFile, onNewChat }) {
  return (
    <aside className={collapsed ? "hy-side is-collapsed" : "hy-side"}>
      <div className="hy-side-head">
        <span className="lg"><Logo /></span>
        <span className="t">
          <b><bdi dir="ltr">{USER.phone}</bdi></b>
          <small><em>{USER.messagesLeft}</em> پیام باقی‌مانده</small>
        </span>
        <button
          type="button"
          className="hy-collapse"
          aria-label={collapsed ? "باز کردن نوار کناری" : "جمع کردن نوار کناری"}
          aria-expanded={!collapsed}
          onClick={onToggleCollapse}
        >
          <Icon name="sidebar" />
        </button>
      </div>

      <div className="hy-side-body">
        <Group icon="folder" title="پرونده‌ها" addLabel="پرونده جدید" onAdd={onNewFile}>
          {CASE_FILES.map((f) => (
            <Item key={f.id} id={f.id} icon="folder" title={f.title} active={activeId === f.id} onSelect={onSelect}>
              <small>{f.meta}</small>
            </Item>
          ))}
        </Group>

        <Group icon="docCheck" title="درخواست‌ها">
          {REQUESTS.map((r) => (
            <Item key={r.id} id={r.id} icon={r.icon} title={r.title} count={r.count} active={activeId === r.id} onSelect={onSelect} />
          ))}
        </Group>

        <Group icon="chat" title="آخرین گفتگوها" addLabel="گفتگوی جدید" onAdd={onNewChat}>
          {RECENT_CHATS.map((c) => (
            <Item key={c.id} id={c.id} icon="scale" title={c.title} active={activeId === c.id} onSelect={onSelect}>
              <small><span>{c.messages}</span><span>{c.date}</span></small>
            </Item>
          ))}
        </Group>
      </div>
    </aside>
  );
}
