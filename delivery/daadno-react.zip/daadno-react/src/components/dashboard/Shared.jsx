import Icon from "../Icon";
import { ACTIVITY, QUICK_TOOLS, SERVICES } from "../../data/dashboard";

// Pieces the desktop and mobile dashboards share; the layout CSS (`.hy-app` vs
// `.hy-m`) restyles them for each.

export function Composer({ value, onChange, onSend, inputRef, hint }) {
  const empty = !value.trim();
  function submit(e) {
    e.preventDefault();
    if (!empty) onSend(value.trim());
  }
  return (
    <form className="hy-composer" onSubmit={submit}>
      <textarea
        ref={inputRef}
        className="ph"
        rows={2}
        aria-label="مسئله حقوقی شما"
        placeholder="مثلاً: برای فسخ قرارداد اجاره چه شرایطی دارم؟"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => {
          // Enter sends, Shift+Enter breaks the line.
          if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) submit(e);
        }}
      />
      <div className="row">
        <button type="submit" className="hy-send" aria-label="ارسال" disabled={empty}>
          <Icon name="send" />
        </button>
        <span className="sp" />
        {hint && <span className="hint">{hint}</span>}
        <button type="button" className="hy-attach" aria-label="پیوست فایل">
          <Icon name="clip" />
        </button>
      </div>
    </form>
  );
}

export function QuickTools({ onPick }) {
  return (
    <div className="hy-chips">
      {QUICK_TOOLS.map((t) => (
        <button key={t.label} type="button" className="hy-chip" onClick={() => onPick(t.prompt)}>
          <Icon name={t.icon} />{t.label}
        </button>
      ))}
    </div>
  );
}

export function ServiceGrid({ className, onOpen }) {
  return (
    <section>
      <div className="hy-sec-h">
        <h3>با چی می‌تونم کمکتون کنم؟</h3>
      </div>
      <div className={className}>
        {SERVICES.map((s) => (
          <button
            key={s.id}
            type="button"
            className={s.featured ? "hy-svc feat" : "hy-svc"}
            onClick={() => onOpen(s.id)}
          >
            <span className="ic"><Icon name={s.icon} /></span>
            <span className="tx">
              <b>{s.title}{s.badge && <span className="hy-badge">{s.badge}</span>}</b>
              <span>{s.text}</span>
            </span>
            <span className="go"><Icon name="arrowLeft" /></span>
          </button>
        ))}
      </div>
    </section>
  );
}

export function RecentActivity() {
  return (
    <section className="hy-panel">
      <div className="hy-sec-h">
        <h3><Icon name="clock" />فعالیت‌های اخیر</h3>
        <a className="hy-link" href="#">مشاهده همه<Icon name="arrowLeft" /></a>
      </div>
      <div className="hy-act">
        {ACTIVITY.map((a) => (
          <div key={a.id}>
            <span className="ic"><Icon name={a.icon} /></span>
            <span className="t"><b>{a.title}</b><small>{a.note}</small></span>
            <time>{a.when}</time>
          </div>
        ))}
      </div>
    </section>
  );
}

// Theme toggle and notifications: the same two buttons, styled per layout.
export function HeaderActions({ btnClass, theme, onToggleTheme, hasNews = true }) {
  const dark = theme === "dark";
  return (
    <>
      <button
        type="button"
        className={btnClass}
        aria-label={dark ? "حالت روشن" : "حالت تاریک"}
        aria-pressed={dark}
        onClick={onToggleTheme}
      >
        <Icon name={dark ? "sun" : "moon"} />
      </button>
      <button type="button" className={btnClass} aria-label={hasNews ? "اعلان‌ها (جدید)" : "اعلان‌ها"}>
        <Icon name="bell" />
        {hasNews && <span className="hy-dot" />}
      </button>
    </>
  );
}
