import { useState } from "react";
import { FAQ } from "../../data/landing";

// Native <details>, as in the design (keyboard and screen readers work for free);
// React keeps one question open at a time, starting with the first.
export default function Faq() {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <section className="lp-sec" id="faq" style={{ paddingTop: 0 }}>
      <div className="lp-wrap">
        <div className="lp-h">
          <h2>سؤالات متداول</h2>
        </div>
        <div className="lp-faq">
          {FAQ.map((item, i) => (
            <details
              key={item.q}
              open={openIndex === i}
              onToggle={(e) => {
                if (e.currentTarget.open) setOpenIndex(i);
                else if (openIndex === i) setOpenIndex(-1);
              }}
            >
              <summary>
                {item.q}
                <span className="pm" aria-hidden="true" />
              </summary>
              <p>{item.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
