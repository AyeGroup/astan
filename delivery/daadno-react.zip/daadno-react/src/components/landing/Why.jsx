import Icon from "../Icon";
import { WHY } from "../../data/landing";

export default function Why() {
  return (
    <section className="lp-sec">
      <div className="lp-wrap">
        <div className="lp-h">
          <h2>کار حقوقی لازم نیست سخت باشد</h2>
        </div>
        <div className="lp-why">
          {WHY.map((w) => (
            <div key={w.title} className={`lp-tile t-${w.tone}`}>
              <span className={`big c-${w.tone}`}><Icon name={w.icon} /></span>
              <h3>{w.title}</h3>
              <p>{w.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
