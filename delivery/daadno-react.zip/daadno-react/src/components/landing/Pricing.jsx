import { Link } from "react-router-dom";
import Icon from "../Icon";
import { PLANS } from "../../data/landing";

function Plan({ plan }) {
  return (
    <div className={plan.popular ? "pl pop" : "pl"}>
      {plan.popular && <span className="badge"><Icon name="star" />محبوب‌ترین</span>}
      <span className={`ic t-${plan.tone} c-${plan.tone}`}><Icon name={plan.icon} /></span>
      <h3>{plan.name}</h3>
      <div className="pr">{plan.price}<small>{plan.unit}</small></div>
      <div className="msg2">{plan.messages}</div>
      <ul>
        {plan.features.map((f) => (
          <li key={f.label} className={f.on ? undefined : "off"}>
            <span><Icon name={f.on ? "check" : "minus"} /></span>{f.label}
          </li>
        ))}
      </ul>
      <Link className={`lp-btn ${plan.btn}`} to="/dashboard">{plan.cta}</Link>
    </div>
  );
}

export default function Pricing() {
  return (
    <section className="lp-sec" id="pricing" style={{ paddingTop: 0 }}>
      <div className="lp-wrap">
        <div className="lp-h">
          <h2>طرحی که با نیاز شما جور باشد</h2>
          <p>شروع رایگان است. هر زمان نیاز داشتید، ارتقا دهید.</p>
        </div>
        <div className="lp-price">
          {PLANS.map((p) => <Plan key={p.name} plan={p} />)}
        </div>
        <p className="lp-note">همه اشتراک‌ها ماهانه‌اند و هر زمان بخواهید می‌توانید طرحتان را تغییر دهید.</p>
      </div>
    </section>
  );
}
