import { Link } from "react-router-dom";
import Icon from "../Icon";
import { AUDIENCES } from "../../data/landing";

export default function Audience() {
  return (
    <section className="lp-sec">
      <div className="lp-wrap">
        <div className="lp-h">
          <h2>برای هر کسی که با حقوق سروکار دارد</h2>
        </div>
        <div className="lp-aud">
          {AUDIENCES.map((a) => (
            <div key={a.who} className={`ac t-${a.tone}`}>
              <span className={`who c-${a.tone}`}><Icon name={a.icon} />{a.who}</span>
              <h3>{a.title}</h3>
              <p>{a.text}</p>
              <Link className="lp-btn pri" to="/dashboard">{a.cta}</Link>
              <span className={`deco c-${a.tone}`}><Icon name={a.decoIcon} /></span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
