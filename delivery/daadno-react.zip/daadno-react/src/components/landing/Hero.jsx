import { useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../Icon";
import Logo from "../Logo";
import appHome from "../../assets/images/app-home.jpg";
import { HERO_CHIPS, HERO_FLOATS, NAV_LINKS } from "../../data/landing";

function Nav() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);

  return (
    <>
      <div className="lp-nav on-dark">
        <Logo />
        <nav>
          {NAV_LINKS.map((l) => (
            <a key={l.href} href={l.href}>{l.label}</a>
          ))}
        </nav>
        <span className="sp" />
        <Link className="login" to="/dashboard">ورود</Link>
        <Link className="lp-btn sun sm" to="/dashboard">شروع رایگان</Link>
        <button
          type="button"
          className="burger"
          aria-label={open ? "بستن منو" : "باز کردن منو"}
          aria-expanded={open}
          aria-controls="lp-mnav"
          onClick={() => setOpen((v) => !v)}
        >
          <Icon name={open ? "x" : "menu"} />
        </button>
      </div>
      {open && (
        <div className="lp-mnav" id="lp-mnav">
          {NAV_LINKS.map((l) => (
            <a key={l.href} href={l.href} onClick={close}>{l.label}</a>
          ))}
          <div className="acts">
            <Link className="lp-btn sun" to="/dashboard">شروع رایگان</Link>
            <Link className="lp-btn ghostw" to="/dashboard">ورود</Link>
          </div>
        </div>
      )}
    </>
  );
}

export default function Hero() {
  return (
    <header className="lp-hero">
      <div className="deco">
        <span style={{ width: 520, height: 520, right: -180, top: -260 }} />
        <span style={{ width: 260, height: 260, left: -90, bottom: -130, opacity: 0.35 }} />
      </div>
      <div className="lp-wrap">
        <Nav />
        <div className="lp-hero-grid">
          <div>
            <span className="lp-pill">
              <b><Icon name="sparkle" /></b>دستیار حقوقی هوشمند
            </span>
            <h1>از اولین سؤال تا ثبت در سامانه، دادنو کنار شماست</h1>
            <p className="sub">
              مشاوره حقوقی، تنظیم اظهارنامه و لایحه، تحلیل قرارداد و استعلام‌های قضایی، همه در یک جا.
              پاسخ‌هایی روشن و مستند به قانون، در چند دقیقه.
            </p>
            <div className="lp-cta">
              <Link className="lp-btn sun" to="/dashboard">شروع رایگان</Link>
              <a className="lp-btn ghostw" href="#try">
                <Icon name="play" />دیدن دادنو در عمل
              </a>
            </div>
            <div className="lp-chips">
              {HERO_CHIPS.map((c) => (
                <span key={c.label}><Icon name={c.icon} />{c.label}</span>
              ))}
            </div>
            <div className="lp-proof">
              <span className="ic"><Icon name="users" /></span>
              <span><b>بیش از ۱۱ هزار کاربر</b>فعال روی پلتفرم عدل ایران</span>
            </div>
          </div>

          <div className="stage" aria-label="نمای اپ دادنو روی موبایل">
            <span className="disc" />
            <span className="ring" />
            <span className="dotgrid" />
            <div className="phone">
              <span className="notch" />
              <div className="scr">
                <img src={appHome} alt="صفحه خانه اپ دادنو" />
              </div>
            </div>
            {HERO_FLOATS.map((f) => (
              <div key={f.cls} className={`float ${f.cls}`}>
                <span className={`ic t-${f.tone} c-${f.tone}`}><Icon name={f.icon} /></span>
                <span><b>{f.title}</b><small>{f.note}</small></span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}
