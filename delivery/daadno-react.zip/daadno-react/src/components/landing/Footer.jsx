import { Link } from "react-router-dom";
import Icon from "../Icon";
import Logo from "../Logo";
import { CONTACT_PHONE, FOOTER_COLUMNS } from "../../data/landing";

export function FinalCta() {
  return (
    <section style={{ padding: "0 0 24px" }}>
      <div className="lp-wrap">
        <div className="lp-final">
          <div>
            <h2>اولین قدم حقوقی‌تان را همین حالا بردارید</h2>
            <p>سؤال بپرسید، اظهارنامه بنویسید، استعلام بگیرید. همه‌چیز یک جا، با پاسخی که می‌شود به آن اعتماد کرد.</p>
          </div>
          <div className="acts">
            <Link className="lp-btn pri" to="/dashboard">شروع رایگان</Link>
            <a className="lp-btn white" href="#try"><Icon name="chat" />پرسیدن اولین سؤال</a>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="lp-foot">
      <div className="lp-wrap">
        <div className="cols">
          <div className="on-dark">
            <Logo />
            <p className="about">
              دستیار حقوقی هوشمند؛ از اولین سؤال تا ثبت در سامانه. مشاوره، تنظیم اظهارنامه و لایحه،
              استعلام و تحلیل قرارداد در یک جا.
            </p>
            {/* محل قرارگیری کد نماد اعتماد الکترونیکی */}
            <div className="lp-enamad" />
          </div>
          {FOOTER_COLUMNS.map((col) => (
            <div key={col.title}>
              <h4>{col.title}</h4>
              <ul>
                {col.links.map((l) => (
                  <li key={l}><a href="#">{l}</a></li>
                ))}
              </ul>
            </div>
          ))}
          <div className="contact">
            <h4>تماس با ما</h4>
            <div>
              <Icon name="chat" />
              <a href={`tel:${CONTACT_PHONE.tel}`}><bdi dir="ltr">{CONTACT_PHONE.display}</bdi></a>
            </div>
            <Link className="lp-btn sun sm" to="/dashboard">شروع رایگان</Link>
          </div>
        </div>
        <div className="bot">
          <span>پاسخ‌های دادنو به شما مشاوره می‌دهد تا در مسیر درست قدم بردارید و به هیچ عنوان جایگزین وکیل متخصص نیست.</span>
          <span>© مهد دانش آیه</span>
        </div>
      </div>
    </footer>
  );
}

// Shown only under 760px (daadno.css): keeps the two main actions in reach on phones.
export function StickyCta() {
  return (
    <div className="lp-sticky">
      <Link className="lp-btn pri" to="/dashboard">شروع رایگان</Link>
      <a className="lp-btn soft" href="#try">پرسیدن سؤال</a>
    </div>
  );
}
