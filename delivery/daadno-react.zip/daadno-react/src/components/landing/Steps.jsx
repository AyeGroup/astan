import { Link } from "react-router-dom";
import Icon from "../Icon";

// The three steps each carry their own small illustration, so they are written out
// rather than mapped from data.
export default function Steps() {
  return (
    <section className="lp-sec lp-steps-w" id="steps">
      <div className="lp-wrap">
        <div className="lp-h">
          <h2>اظهارنامه و لایحه‌تان را بدون دردسر ثبت کنید</h2>
          <p>از تنظیم تا ثبت، در سه قدم.</p>
        </div>
        <div className="lp-steps">
          <div className="lp-step">
            <span className="n">۱</span>
            <h3>موضوع را بگویید</h3>
            <p>ماجرا را به زبان خودتان بنویسید یا مدارکتان را بارگذاری کنید.</p>
            <div className="mini" aria-hidden="true">
              <div className="in">مستأجر بعد از پایان قرارداد خانه را تخلیه نمی‌کند…</div>
              <span className="up t-cream c-cream"><Icon name="upload" />اجاره‌نامه.pdf</span>
            </div>
          </div>

          <div className="lp-step">
            <span className="n">۲</span>
            <h3>متن را بررسی کنید</h3>
            <p>دادنو متن حقوقی را با استناد به قانون آماده می‌کند. هر بخش را می‌توانید ویرایش کنید.</p>
            <div className="mini" aria-hidden="true">
              <i className="l" /><i className="l g" /><i className="l s" /><i className="l g s" /><i className="l" />
              <span className="pen"><Icon name="pen" />ویرایش این بند</span>
            </div>
          </div>

          <div className="lp-step">
            <span className="n">۳</span>
            <h3>ثبت و پیگیری</h3>
            <p>متن نهایی را ثبت کنید و وضعیتش را از داخل پنل ببینید.</p>
            <div className="mini tl" aria-hidden="true">
              <div className="ok"><span><Icon name="check" /></span>متن نهایی تأیید شد</div>
              <div className="ok"><span><Icon name="check" /></span>در سامانه ثبت شد</div>
              <div className="wait"><span><Icon name="clock" /></span>در انتظار ابلاغ</div>
            </div>
          </div>
        </div>
        <div className="lp-center">
          <Link className="lp-btn pri" to="/dashboard">تنظیم اظهارنامه یا لایحه</Link>
        </div>
      </div>
    </section>
  );
}
