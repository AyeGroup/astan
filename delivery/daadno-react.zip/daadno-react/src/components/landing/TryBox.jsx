import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import Icon from "../Icon";
import { usePrefersReducedMotion } from "../../hooks/useMediaQuery";
import { TRY_PLACEHOLDER, TRY_SUGGESTIONS } from "../../data/landing";

// "Ask your first question": a suggestion types itself into the box, and
// "دریافت پاسخ" carries the question into the dashboard composer (?q=…).
export default function TryBox() {
  const [question, setQuestion] = useState("");
  const timer = useRef(null);
  const reduce = usePrefersReducedMotion();
  const navigate = useNavigate();

  useEffect(() => () => clearInterval(timer.current), []);

  function typeIn(text) {
    clearInterval(timer.current);
    if (reduce) {
      setQuestion(text);
      return;
    }
    let i = 0;
    timer.current = setInterval(() => {
      i += 1;
      setQuestion(text.slice(0, i));
      if (i >= text.length) clearInterval(timer.current);
    }, 28);
  }

  function submit(e) {
    e.preventDefault();
    const q = question.trim();
    navigate(q ? `/dashboard?q=${encodeURIComponent(q)}` : "/dashboard");
  }

  return (
    <section className="lp-sec" id="try" style={{ paddingBottom: 40 }}>
      <div className="lp-wrap">
        <div className="lp-try">
          <div>
            <h2>سؤالتان را بنویسید، پاسخش را ببینید</h2>
            <p className="note"><Icon name="check" />برای اولین سؤال نیازی به ثبت‌نام نیست</p>
            <div className="sugg">
              {TRY_SUGGESTIONS.map((q) => (
                <button key={q} type="button" onClick={() => typeIn(q)}>{q}</button>
              ))}
            </div>
          </div>
          <form className="box" onSubmit={submit}>
            <textarea
              className="ta"
              aria-label="سؤال حقوقی شما"
              placeholder={TRY_PLACEHOLDER}
              value={question}
              onChange={(e) => {
                clearInterval(timer.current);
                setQuestion(e.target.value);
              }}
            />
            <div className="row">
              <button type="button" className="clip" aria-label="پیوست فایل"><Icon name="clip" /></button>
              <span className="sp" />
              <button type="submit" className="lp-btn sun">دریافت پاسخ</button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}
