import Icon from "../Icon";
import { TESTIMONIALS } from "../../data/landing";

// Off, as in the design: turn it on only once the quotes are real and their authors
// have agreed, with each `name` filled in (data/landing.js).
export const SHOW_TESTIMONIALS = false;

export default function Testimonials() {
  if (!SHOW_TESTIMONIALS) return null;
  return (
    <section className="lp-sec" style={{ paddingTop: 0 }}>
      <div className="lp-wrap">
        <div className="lp-h">
          <h2>کاربران دادنو چه می‌گویند</h2>
        </div>
        <div className="lp-tst">
          {TESTIMONIALS.map((t) => (
            <figure key={t.kind} className="tq" style={{ margin: 0 }}>
              <span className={`kind c-${t.tone}`}>{t.kind}</span>
              <div className="stars" aria-label="۵ از ۵">
                {[0, 1, 2, 3, 4].map((i) => <Icon key={i} name="star" />)}
              </div>
              <blockquote>{t.quote}</blockquote>
              <div className="who">
                <span className={`av t-${t.tone} c-${t.tone}`}><Icon name="users" /></span>
                <div>
                  <b>{t.name ?? <span className="ph-mark">[نام کاربر]</span>}</b>
                </div>
              </div>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
