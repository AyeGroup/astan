import Icon from "../Icon";
import { MARQUEE, STATS } from "../../data/landing";

export function Stats() {
  return (
    <section className="lp-wrap">
      <div className="lp-stats">
        {STATS.map((s) => (
          <div key={s.label} className={`lp-stat t-${s.tone}`}>
            <span className={`ic c-${s.tone}`}><Icon name={s.icon} /></span>
            <span><b>{s.value}</b><span>{s.label}</span></span>
          </div>
        ))}
      </div>
    </section>
  );
}

// The track holds the list twice and slides by half its width, so the loop is seamless.
export function Marquee() {
  const items = [...MARQUEE, ...MARQUEE];
  return (
    <div className="lp-marq" aria-hidden="true">
      <div className="track">
        {items.map((m, i) => (
          <span key={i}><Icon name={m.icon} />{m.label}</span>
        ))}
      </div>
    </div>
  );
}
