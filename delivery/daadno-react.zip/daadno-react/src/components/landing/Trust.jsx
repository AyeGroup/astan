import Icon from "../Icon";
import ChatDemo from "./ChatDemo";
import { TRUST_POINTS } from "../../data/landing";

export default function Trust() {
  return (
    <section className="lp-sec" id="demo" style={{ paddingTop: 0 }}>
      <div className="lp-wrap">
        <div className="lp-h">
          <h2>پاسخی که بتوانید به آن تکیه کنید</h2>
        </div>
        <div className="lp-trust">
          <ChatDemo />
          <ul className="pts">
            {TRUST_POINTS.map((p) => (
              <li key={p.title}>
                <span className={`ic t-${p.tone} c-${p.tone}`}><Icon name={p.icon} /></span>
                <div>
                  <h3>{p.title}</h3>
                  <p>{p.text}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
