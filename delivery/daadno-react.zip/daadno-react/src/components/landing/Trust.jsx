import Icon from "../Icon";
import { TRUST_POINTS } from "../../data/landing";

export default function Trust() {
  return (
    <section className="lp-sec" style={{ paddingTop: 0 }}>
      <div className="lp-wrap">
        <div className="lp-h">
          <h2>پاسخی که بتوانید به آن تکیه کنید</h2>
        </div>
        <div className="lp-trust">
          <div className="ansc">
            <div className="q">
              <span><Icon name="chat" /></span>آیا اجاره با تمام شدن مدتش خودبه‌خود تمام می‌شود؟
            </div>
            <div className="a">
              بله. عقد اجاره به محض انقضای مدت برطرف می‌شود<sup>۱</sup> و اگر مستأجر پس از آن ملک را
              تخلیه نکند، موجر می‌تواند از مرجع قضایی دستور تخلیه بخواهد<sup>۲</sup>.
            </div>
            <div className="srcs">
              <span><b>۱</b>ماده ۴۹۴ قانون مدنی</span>
              <span><b>۲</b>قانون روابط موجر و مستأجر، مصوب ۱۳۷۶</span>
            </div>
          </div>
          <ul className="pts">
            {TRUST_POINTS.map((p) => (
              <li key={p.title}>
                <span className={`ic t-${p.tone} c-${p.tone}`}><Icon name={p.icon} /></span>
                <div>
                  <h3>{p.title}</h3>
                  <p>{p.text}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
