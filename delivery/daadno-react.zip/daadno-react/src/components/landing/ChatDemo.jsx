import { useEffect, useMemo, useRef, useState } from "react";
import Icon from "../Icon";
import { useInView } from "../../hooks/useInView";
import { usePrefersReducedMotion } from "../../hooks/useMediaQuery";
import { CHAT_DEMO } from "../../data/landing";

// The Q&A card in "پاسخی که بتوانید به آن تکیه کنید", played as a live chat:
// the question arrives, Daadno "types", the answer streams in word by word with its
// citation marks, then the sources appear. It loops while the card is on screen,
// pauses off screen, and shows the finished card when the visitor prefers reduced
// motion. The full answer is always laid out (unrevealed words are invisible), so
// the card never changes height while it plays.

const T = { question: 400, typing: 1200, stream: 2700, wordEvery: 55, sourcesAfter: 450, hold: 4200 };

// Answer → tokens: each word and each run of spaces is one token, a citation is one.
function tokenize(parts) {
  const tokens = [];
  for (const p of parts) {
    if (p.cite) tokens.push({ cite: p.cite });
    else for (const w of p.text.split(/(\s+)/)) if (w) tokens.push({ text: w });
  }
  return tokens;
}

export default function ChatDemo() {
  const ref = useRef(null);
  const inView = useInView(ref);
  const reduce = usePrefersReducedMotion();
  const tokens = useMemo(() => tokenize(CHAT_DEMO.answer), []);
  const words = tokens.length;

  // phase: 0 empty · 1 question · 2 typing · 3 streaming · 4 sources shown
  const [phase, setPhase] = useState(0);
  const [shown, setShown] = useState(0);

  useEffect(() => {
    if (reduce || !inView) return undefined;
    const timers = [];
    const at = (ms, fn) => timers.push(setTimeout(fn, ms));

    function play() {
      setPhase(0);
      setShown(0);
      at(T.question, () => setPhase(1));
      at(T.typing, () => setPhase(2));
      at(T.stream, () => setPhase(3));
      for (let i = 1; i <= words; i += 1) at(T.stream + i * T.wordEvery, () => setShown(i));
      const end = T.stream + words * T.wordEvery + T.sourcesAfter;
      at(end, () => setPhase(4));
      at(end + T.hold, play);
    }

    play();
    return () => timers.forEach(clearTimeout);
  }, [inView, reduce, words]);

  const done = reduce || phase === 4;
  const visible = reduce ? words : shown;
  const on = (n) => (reduce || phase >= n ? " on" : "");

  return (
    <div className={`ansc chat-demo${reduce ? "" : " is-anim"}`} ref={ref}>
      <div className={`q${on(1)}`}>
        <span><Icon name="chat" /></span>{CHAT_DEMO.question}
      </div>

      <div className={`a${on(2)}`} aria-live="off">
        {/* Screen readers get the whole answer at once, not word by word. */}
        <span className="sr-only">{CHAT_DEMO.answer.map((p) => p.text ?? `[${p.cite}]`).join("")}</span>
        <span aria-hidden="true">
          {tokens.map((t, i) => {
            const cls = i < visible ? "w in" : "w";
            return t.cite
              ? <sup key={i} className={cls}>{t.cite}</sup>
              : <span key={i} className={cls}>{t.text}</span>;
          })}
        </span>
        {!reduce && phase === 2 && (
          <span className="typing" aria-label="دادنو در حال نوشتن است"><i /><i /><i /></span>
        )}
      </div>

      <div className={`srcs${done ? " on" : ""}`}>
        {CHAT_DEMO.sources.map((s) => (
          <span key={s.n}><b>{s.n}</b>{s.text}</span>
        ))}
      </div>
    </div>
  );
}
