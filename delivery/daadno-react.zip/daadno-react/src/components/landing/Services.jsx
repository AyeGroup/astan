import { Link } from "react-router-dom";
import Icon from "../Icon";
import { CALCULATORS, SERVICE_CATEGORIES, SERVICES } from "../../data/landing";

function ServiceCard({ cat, icon, title, text }) {
  const { tone, label } = SERVICE_CATEGORIES[cat];
  return (
    <div className="bx">
      <div className="top">
        <span className={`ic t-${tone} c-${tone}`}><Icon name={icon} /></span>
        <span className={`cat t-${tone} c-${tone}`}>{label}</span>
      </div>
      <h3>{title}</h3>
      <p>{text}</p>
    </div>
  );
}

export default function Services() {
  return (
    <section className="lp-sec" id="services" style={{ paddingTop: 0 }}>
      <div className="lp-wrap">
        <div className="lp-h">
          <h2>هر چه برای یک مسئله حقوقی لازم دارید، اینجاست</h2>
          <p>از پرسیدن سؤال تا ثبت درخواست، بدون جابه‌جایی بین سامانه‌ها.</p>
        </div>
        <div className="bento">
          <div className="bx hero">
            <h3>تنظیم و ثبت اظهارنامه</h3>
            <p>موضوعتان را بگویید تا متن اظهارنامه را دقیق و حقوقی برایتان بنویسیم و برای ثبت آماده کنیم.</p>
            <Link className="lp-btn pri sm" to="/dashboard">تنظیم اظهارنامه</Link>
            <div className="docmini" aria-hidden="true">
              <span className="ok"><Icon name="check" /></span>
              <b>اظهارنامه</b>
              <i /><i className="g" /><i className="s" /><i /><i className="g s" />
            </div>
          </div>

          {SERVICES.map((s) => <ServiceCard key={s.title} {...s} />)}

          <div className="bx wide">
            <span className="ic t-sun c-sun" style={{ background: "var(--surface-000)" }}>
              <Icon name="calculator" />
            </span>
            <div className="tx">
              <h3>محاسبه‌گرهای حقوقی</h3>
              <p>مهریه، دیه، نفقه و خسارت تأخیر، دقیق و بر اساس نرخ روز.</p>
            </div>
            <div className="calcui">
              {CALCULATORS.map((c) => (
                <span key={c}><Icon name="calculator" />{c}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
