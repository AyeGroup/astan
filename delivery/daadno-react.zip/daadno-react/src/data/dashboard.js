// Sample content for the user dashboard, matching the design. In production these
// come from the API; the components only depend on the shapes below.

export const USER = {
  firstName: "زهرا",
  phone: "۰۹۱۲ ۳۴۵ ۶۷۸۹",
  messagesLeft: "۲۱۱",
};

export const CASE_FILES = [
  { id: "f1", title: "سلام", meta: "۱ سند · ۱۰ گفتگو" },
];

export const REQUESTS = [
  { id: "notices", icon: "docCheck", title: "اظهارنامه‌های ارسالی", count: "۲" },
  { id: "briefs", icon: "pen", title: "لایحه‌های ارسالی" },
  { id: "records", icon: "shield", title: "سوء پیشینه‌ها" },
  { id: "credit", icon: "bank", title: "اعتبار معاملاتی" },
];

export const RECENT_CHATS = [
  { id: "c1", title: "تنظیم اظهارنامه ارث", messages: "۴ پیام", date: "۱۴۰۵/۰۷/۰۸" },
  { id: "c2", title: "راهنمای تنظیم لایحه حقوقی", messages: "۲ پیام", date: "۱۴۰۵/۰۷/۰۴" },
  { id: "c3", title: "تنظیم اظهارنامه شکایت از مدیر", messages: "۶ پیام", date: "۱۴۰۵/۰۷/۰۱" },
];

// Quick tools under the composer; `prompt` is what a click writes into it.
export const QUICK_TOOLS = [
  { icon: "docCheck", label: "تنظیم اظهارنامه", prompt: "می‌خواهم یک اظهارنامه تنظیم کنم. موضوع: " },
  { icon: "pen", label: "تنظیم لایحه", prompt: "می‌خواهم یک لایحه تنظیم کنم. موضوع پرونده: " },
  { icon: "docSearch", label: "تشریح اسناد قضایی", prompt: "این سند قضایی را برایم توضیح بده: " },
  { icon: "shield", label: "تحلیل ریسک قرارداد", prompt: "ریسک‌های این قرارداد را بررسی کن: " },
];

export const SERVICES = [
  { id: "judicial", icon: "bank", title: "خدمات قضایی", text: "استعلام و دسترسی به خدمات قوه قضاییه" },
  { id: "case", icon: "folderSearch", title: "تحلیل پرونده", text: "بررسی اسناد و روند پرونده با هوش مصنوعی" },
  { id: "best", icon: "bulb", title: "بهترین راهکار حقوقی", text: "پیشنهاد مسیر بهینه بر اساس شرایط شما", badge: "پیشنهاد هوشمند", featured: true },
  { id: "lawyer", icon: "userCheck", title: "مشاوره و اخذ وکیل", text: "پاسخ به سؤالات و معرفی وکیل متخصص" },
  { id: "fee", icon: "card", title: "تسهیلات حق‌الوکاله", text: "پرداخت اقساطی هزینه وکیل" },
  { id: "mahr", icon: "ring", title: "پرداخت مهریه", text: "تسهیلات و پرداخت اقساطی مهریه", badge: "جدید" },
];

export const ACTIVITY = [
  { id: "a1", icon: "shield", title: "تحلیل ریسک قرارداد اجاره", note: "بررسی بندهای مهم قرارداد", when: "۲ ساعت پیش" },
  { id: "a2", icon: "docCheck", title: "تنظیم اظهارنامه", note: "اظهارنامه واخواست", when: "دیروز" },
  { id: "a3", icon: "folder", title: "بررسی پرونده شماره ۱۴۰۳…", note: "وضعیت روند پرونده", when: "۳ روز پیش" },
];

export const MOBILE_TABS = [
  { id: "home", icon: "home", label: "خانه" },
  { id: "chats", icon: "chat", label: "گفتگوها" },
  { id: "files", icon: "folder", label: "پرونده‌ها" },
  { id: "settings", icon: "gear", label: "تنظیمات" },
];
