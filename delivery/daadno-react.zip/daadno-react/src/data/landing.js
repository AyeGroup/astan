// Everything the landing page says, kept apart from its layout so copy, prices and
// FAQ answers can change without touching a component.
// `tone` picks the tinted background/ink pair defined in daadno.css (t-* / c-*).

export const NAV_LINKS = [
  { href: "#services", label: "خدمات" },
  { href: "#steps", label: "روند ثبت" },
  { href: "#pricing", label: "تعرفه‌ها" },
  { href: "#faq", label: "سؤالات" },
];

export const HERO_CHIPS = [
  { icon: "scale", label: "مشاوره حقوقی" },
  { icon: "docCheck", label: "اظهارنامه" },
  { icon: "pen", label: "لایحه" },
  { icon: "shield", label: "سوءپیشینه" },
  { icon: "briefcase", label: "اعتبار معاملاتی" },
  { icon: "docSearch", label: "تحلیل قرارداد" },
];

export const HERO_FLOATS = [
  { cls: "f1", tone: "mint", icon: "check", title: "اظهارنامه ثبت شد", note: "وضعیت را از پنل ببینید" },
  { cls: "f2", tone: "sun", icon: "book", title: "پاسخ با منبع قانونی", note: "ماده و رأی مرتبط کنار هر جواب" },
  { cls: "f3", tone: "cream", icon: "briefcase", title: "استعلام اعتبار معاملاتی", note: "دریافت شد" },
];

export const STATS = [
  { tone: "mint", icon: "users", value: "+۱۱ هزار", label: "کاربر فعال" },
  { tone: "cream", icon: "chat", value: "+۱۴ هزار", label: "پیام پاسخ‌داده‌شده" },
  { tone: "sage", icon: "clock", value: "۲۴ ساعته", label: "پاسخ‌گویی در تمام شبانه‌روز" },
  { tone: "sun", icon: "bank", value: "عدل ایران", label: "فعال روی پلتفرم" },
];

export const MARQUEE = [
  { icon: "docCheck", label: "تنظیم اظهارنامه" },
  { icon: "pen", label: "تنظیم لایحه" },
  { icon: "shield", label: "استعلام سوءپیشینه" },
  { icon: "briefcase", label: "اعتبار معاملاتی" },
  { icon: "docSearch", label: "تحلیل قرارداد" },
  { icon: "scale", label: "مشاوره حقوقی" },
  { icon: "calculator", label: "محاسبه مهریه" },
  { icon: "folderSearch", label: "تحلیل پرونده" },
  { icon: "bank", label: "خدمات قضایی" },
];

export const TRY_PLACEHOLDER = "مثلاً: «برای فسخ قرارداد اجاره چه شرایطی دارم؟»";

export const TRY_SUGGESTIONS = [
  "برای فسخ قرارداد اجاره چه شرایطی دارم؟",
  "مهریه به نرخ روز چقدر می‌شود؟",
  "چک برگشتی را چطور پیگیری کنم؟",
];

export const WHY = [
  { tone: "sun", icon: "coin", title: "هزینه مشاوره", text: "مشاوره حقوقی گران است و نوبتش دیر می‌رسد. دادنو هر ساعت از شبانه‌روز در دسترس شماست." },
  { tone: "cream", icon: "compass", title: "ابهام در مسیر", text: "نمی‌دانید از کجا شروع کنید؟ دادنو قدم‌به‌قدم نشانتان می‌دهد چه کنید و به کجا مراجعه کنید." },
  { tone: "sage", icon: "lines", title: "زبان پیچیده قانون", text: "مواد قانونی را به زبان ساده می‌خوانید و منبع هر پاسخ را کنارش می‌بینید." },
  { tone: "butter", icon: "clock", title: "دوندگی و صف", text: "اظهارنامه، لایحه و استعلام‌ها را بدون سردرگمی در سامانه‌ها، از همین‌جا انجام دهید." },
];

export const SERVICE_CATEGORIES = {
  file: { tone: "mint", label: "تنظیم و ثبت" },
  inquiry: { tone: "cream", label: "استعلام" },
  advice: { tone: "sage", label: "مشاوره و تحلیل" },
};

export const SERVICES = [
  { cat: "file", icon: "pen", title: "تنظیم و ثبت لایحه", text: "لایحه‌ای منظم و مستدل، متناسب با پرونده شما. پیش‌نویس را بررسی کنید و همان‌جا ثبتش کنید." },
  { cat: "file", icon: "docText", title: "تنظیم اسناد حقوقی", text: "قرارداد، شکواییه، دادخواست و سایر متن‌های حقوقی، آماده در چند دقیقه." },
  { cat: "inquiry", icon: "shield", title: "استعلام سوءپیشینه", text: "درخواست استعلام را از همین‌جا ثبت کنید و وضعیتش را پیگیری کنید." },
  { cat: "inquiry", icon: "briefcase", title: "استعلام اعتبار معاملاتی", text: "قبل از امضای قرارداد یا معامله، از وضعیت اعتباری و حقوقی طرف مقابل مطمئن شوید." },
  { cat: "inquiry", icon: "bank", title: "استعلام و خدمات قضایی", text: "دسترسی به خدمات مرتبط با قوه قضاییه، بدون پیچیدگی." },
  { cat: "advice", icon: "scale", title: "مشاوره حقوقی", text: "سؤالتان را بپرسید و پاسخ مستند به قانون بگیرید. اگر لازم شد، به یک متخصص حقوقی وصل می‌شوید." },
  { cat: "advice", icon: "docSearch", title: "تحلیل قرارداد", text: "قرارداد را بارگذاری کنید تا بندهای حساس و ریسک‌هایش را نشانتان بدهیم." },
  { cat: "advice", icon: "folderSearch", title: "تحلیل پرونده", text: "اسناد و روند پرونده را بررسی و جمع‌بندی کنید، با کمک هوش مصنوعی." },
];

export const CALCULATORS = ["مهریه", "دیه", "نفقه", "خسارت تأخیر"];

export const AUDIENCES = [
  {
    tone: "mint", icon: "users", who: "عموم مردم", decoIcon: "scale",
    title: "قبل از هر اقدام، مطمئن شوید",
    text: "حقوق و تکالیفتان را بشناسید. اظهارنامه بفرستید، استعلام بگیرید و بدون نگرانی از هزینه‌های سنگین تصمیم بگیرید.",
    cta: "شروع رایگان",
  },
  {
    tone: "sun", icon: "briefcase", who: "کسب‌وکارها", decoIcon: "briefcase",
    title: "هر معامله را با اطمینان ببندید",
    text: "پیش از قرارداد، اعتبار معاملاتی طرف مقابل را استعلام کنید و قراردادتان را قبل از امضا بررسی کنید.",
    cta: "استعلام اعتبار معاملاتی",
  },
];

export const TRUST_POINTS = [
  { tone: "sun", icon: "book", title: "ارجاع به منبع", text: "هر پاسخ با ماده قانونی یا رأی مرتبط همراه است تا خودتان هم بتوانید بررسی‌اش کنید." },
  { tone: "sage", icon: "userCheck", title: "مشاوره تخصصی، در صورت نیاز", text: "برای پرونده‌های حساس، دسترسی به مشاوره تخصصی همیشه یک قدم فاصله دارد." },
  { tone: "mint", icon: "lock", title: "حریم خصوصی", text: "اطلاعات و مدارک شما محرمانه می‌ماند و فقط برای ارائه خدمت به خودتان استفاده می‌شود." },
];

// Hidden until real reviews (and the reviewers' consent) are in: see SHOW_TESTIMONIALS
// in Testimonials.jsx. Replace each [نام کاربر] with the real name before turning it on.
export const TESTIMONIALS = [
  { tone: "mint", kind: "تنظیم اظهارنامه", quote: "«مستأجرم بعد از پایان قرارداد خانه را تخلیه نمی‌کرد. با دادنو در چند دقیقه اظهارنامه نوشتم و همان‌جا ثبتش کردم؛ بدون رفت‌وآمد و سردرگمی.»", name: null },
  { tone: "cream", kind: "استعلام اعتبار معاملاتی", quote: "«قبل از بستن قرارداد با یک تأمین‌کننده جدید، اعتبار معاملاتی‌اش را استعلام گرفتم. همین یک استعلام جلوی یک ضرر جدی را گرفت.»", name: null },
  { tone: "sage", kind: "مشاوره حقوقی", quote: "«سؤالم درباره مهریه بود. جواب ساده و روشن بود و ماده قانونی‌اش هم کنارش آمده بود؛ با خیال راحت تصمیم گرفتم.»", name: null },
];

const SERVICE_NAMES = ["ثبت اظهارنامه", "ثبت لایحه", "استعلام سوءپیشینه", "استعلام اعتبار معاملاتی"];
// `count` is the monthly quota as shown (e.g. "۱"); none means the plan lacks the service.
const included = (count) => SERVICE_NAMES.map((n) => ({ on: Boolean(count), label: count ? `${count} ${n}` : n }));

export const PLANS = [
  { tone: "mint", icon: "sparkle", name: "رایگان", price: "رایگان", unit: "بدون پرداخت", messages: "۲ پیام در ماه", features: included(), cta: "شروع رایگان", btn: "line" },
  { tone: "cream", icon: "chat", name: "پایه", price: "۲۰۰", unit: "هزار تومان در ماه", messages: "۱۰ پیام در ماه", features: included(), cta: "انتخاب طرح پایه", btn: "line" },
  { tone: "sun", icon: "docCheck", name: "حرفه‌ای", price: "۵۰۰", unit: "هزار تومان در ماه", messages: "۵۰ پیام در ماه", features: included("۱"), cta: "انتخاب طرح حرفه‌ای", btn: "sun", popular: true },
  { tone: "sage", icon: "briefcase", name: "پیشرفته", price: "۱٫۲۰۰٫۰۰۰", unit: "تومان در ماه", messages: "۱۲۰ پیام در ماه", features: included("۳"), cta: "انتخاب طرح پیشرفته", btn: "pri" },
];

export const FAQ = [
  { q: "آیا دادنو جای وکیل را می‌گیرد؟", a: "نه. دادنو برای آگاهی، تصمیم‌گیری بهتر و مشاوره است. برای پرونده‌های پیچیده، مشاوره با وکیل را توصیه می‌کنیم و مسیر آن را هم فراهم کرده‌ایم." },
  { q: "پاسخ‌های دادنو چقدر قابل اعتمادند؟", a: "پاسخ‌ها بر پایه قوانین و آرای معتبر و همراه با منبع ارائه می‌شوند تا هر موردی را بتوانید بررسی کنید." },
  { q: "هر «پیام» چیست؟", a: "هر سؤالی که از دادنو می‌پرسید یک پیام حساب می‌شود." },
  { q: "اگر پیام‌هایم تمام شود چه می‌شود؟", a: "در صورت اتمام پیام‌ها، باید دوباره یک طرح جدید تهیه کنید." },
  { q: "اظهارنامه، لایحه و استعلام‌ها در کدام طرح‌ها هستند؟", a: "ثبت اظهارنامه و لایحه و دریافت استعلام‌ها در طرح‌های حرفه‌ای و پیشرفته ارائه می‌شود. طرح حرفه‌ای شامل ۱ مورد از هر خدمت و طرح پیشرفته شامل ۳ مورد از هر خدمت در ماه است." },
  { q: "آیا اعتبار خدمات و پیام‌ها به ماه بعد منتقل می‌شود؟", a: "بعد از خرید هر طرح، باید از خدمات آن طرح در همان ماه استفاده کنید. خدمات باقی‌مانده بعد از اتمام ماه منتقل نمی‌شوند." },
  { q: "اظهارنامه و لایحه چطور ثبت می‌شود؟", a: "برای ثبت اظهارنامه و لایحه، کافی است در چت دادنو متن را بنویسید و بعد از اصلاح به کمک هوش مصنوعی، همان‌جا ارسال کنید. دادنو این امکان را فراهم کرده که بدون هیچ تلاش اضافه‌ای اظهارنامه و لایحه خودتان را ثبت کنید." },
  { q: "چه استعلام‌هایی را می‌توانم انجام دهم؟", a: "استعلام سوءپیشینه، استعلام اعتبار معاملاتی و خدمات قضایی مرتبط." },
  { q: "اطلاعات من محفوظ است؟", a: "بله. اطلاعات و مدارک شما محرمانه است و در اختیار هیچ شخص ثالثی قرار نمی‌گیرد." },
  { q: "دادنو چه حوزه‌هایی را پوشش می‌دهد؟", a: "دادنو با در اختیار داشتن انواع داده‌های متنوع در حوزه‌های مختلف، توانایی پاسخ‌گویی در همه حوزه‌ها را دارد." },
  { q: "چطور اشتراک تهیه کنم؟", a: "بعد از ثبت‌نام، طرح مورد نظرتان را انتخاب و پرداخت کنید. اشتراک‌ها ماهانه‌اند." },
];

export const FOOTER_COLUMNS = [
  { title: "خدمات", links: ["تنظیم اظهارنامه", "تنظیم لایحه", "استعلام سوءپیشینه", "اعتبار معاملاتی", "محاسبه مهریه"] },
  { title: "دادنو", links: ["درباره دادنو", "تعرفه‌ها", "سؤالات متداول", "قوانین و حریم خصوصی"] },
];

export const CONTACT_PHONE = { tel: "09903202903", display: "۰۹۹۰ ۳۲۰ ۲۹۰۳" };
