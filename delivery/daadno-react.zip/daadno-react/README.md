# دادنو — نسخهٔ React

پیاده‌سازی React (با Vite) از طراحی دادنو: صفحهٔ فرود، داشبورد دسکتاپ و داشبورد موبایل.

## اجرا

```bash
npm install
npm run dev       # توسعه: http://localhost:5173
npm run build     # خروجی production در dist/
npm run preview   # دیدن همان خروجی build
```

نیازمند Node 18 یا بالاتر.

## مسیرها

| مسیر | صفحه |
|---|---|
| `/` | صفحهٔ فرود |
| `/dashboard` | داشبورد؛ از عرض ۹۰۰px به بالا نسخهٔ دسکتاپ (با نوار کناری)، زیر آن نسخهٔ موبایل |
| `/dashboard?q=…` | داشبورد با سؤالی که از کادر «سؤالتان را بنویسید» در صفحهٔ فرود آمده |

برای استقرار روی سرور (nginx و…)، همهٔ مسیرها باید به `index.html` برگردند (SPA fallback).

## ساختار

```
src/
  main.jsx, App.jsx          ورودی و مسیریابی (react-router)
  pages/                     Landing و Dashboard
  components/
    Icon.jsx, Logo.jsx       آیکون‌های خطی و لوگو (SVG درون‌خطی)
    landing/                 بخش‌های صفحهٔ فرود، هر بخش یک کامپوننت
    dashboard/               نوار کناری، کادر پرسش، کارت خدمات، چیدمان دسکتاپ و موبایل
  data/                      همهٔ متن‌ها، قیمت‌ها، سؤالات متداول و داده‌های نمونهٔ داشبورد
  hooks/                     useTheme (حالت تاریک) و useMediaQuery
  styles/
    daadno.css               CSS طراحی، بدون تغییر (فقط مسیر فونت‌ها)
    app.css                  افزوده‌های نسخهٔ React
  assets/                    فونت وزیرمتن و تصویر اپ
```

- **تغییر متن یا قیمت:** فقط فایل‌های `src/data/` را ویرایش کنید.
- **حالت تاریک:** دکمهٔ ماه/خورشید در داشبورد؛ انتخاب کاربر در مرورگر ذخیره می‌شود.
- **بخش نظرات کاربران:** مثل طراحی، خاموش است. پس از گرفتن نظر واقعی و رضایت کاربر، نام‌ها را در `data/landing.js` بنویسید و `SHOW_TESTIMONIALS` را در `components/landing/Testimonials.jsx` روی `true` بگذارید.
- **نماد اعتماد:** کدش را در `div.lp-enamad` داخل `components/landing/Footer.jsx` قرار دهید.

## نقاط اتصال به بک‌اند

داده‌های داشبورد فعلاً نمونه‌اند (`src/data/dashboard.js`). جاهایی که باید به API وصل شوند با `TODO` مشخص شده‌اند:

- `pages/Dashboard.jsx` → `onSend`: ارسال سؤال به سرویس چت
- `pages/Dashboard.jsx` → `onOpenService`: رفتن به روند هر خدمت
- `pages/Dashboard.jsx` → `onNewFile`: ساخت پرونده جدید
